#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

void display_reset() {
// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
// Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, OLED_RESET);
	Adafruit_SSD1306 display(OLED_RESET);
}

void display_init(){

  // by default, we'll generate the high voltage from the 3.3v line internally! (neat!)
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  // initialize the I2C addr 0x3C (for the 64x48)
  // init done
  Serial.print("Setup initial display");
  display.display(); // shows Initial default symbol on display
  delay(2000);

  // Clear the buffer.
  display.clearDisplay();
  Serial.print("Setup after clear display");

  // text display tests
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0,0);
  display.println("HH-12");
  display.setCursor(0,10);
  display.println("Test");
  display.display();
  delay(2000);
  display.clearDisplay();
}

void display_angle(float _floatAngle){

	//clear display
	display.clearDisplay();

	// Display Az degrees
	display.setTextSize(1);
	display.setCursor(0,0);
	display.print("HH-12");
	display.setTextSize(1);
	display.setCursor(0,10);
	display.print("Azimuth:");
	display.setTextSize(1);
	display.setCursor(0,20);
	display.print(_floatAngle, 1);
	display.print(" ");
	display.setTextSize(1);
	display.write(167); // Ascii code of Degree symbol
	
	display.display();

}