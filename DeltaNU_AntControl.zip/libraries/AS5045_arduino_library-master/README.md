AS5045_arduino_library
======================

Library for accessing data and error codes from Austrian Microsystems AS5045 12 bit rotary encoder
