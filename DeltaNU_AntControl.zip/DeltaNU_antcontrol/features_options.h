// **** ---------------------- Features and Options, enable them below ------------------------------------------------
#define FEATURE_MOON_TRACKING
#define FEATURE_SUN_TRACKING

#define DEFAULT_GRID "JO99AH"		// Maidenhead grid Stockholm
#define DEFAULT_LATITUDE 59.3293	// Latitude Stockholm
#define DEFAULT_LONGITUDE 18.0686	// Longitude Stockholm

#define TRACKOBJ_PIN 32   // GPIO-32 will be connected to button, to be used to change tracking object

#define WIFI_SSID "Filips Wi-Fi Network"
#define WIFI_PASS "09011977filip"

#define NTP_SERVER "pool.ntp.org"
#define GMTOFFSET_SEC 0   // We want UTC time
#define DAYLIGHTOFFSET_SEC 0 

// OLED Params
// I2C SCL GPI22
// I2C SDA GPI21
#define OLED_RESET 0  // GPIO0
#define SCREEN_WIDTH 64 // OLED display width, in pixels
#define SCREEN_HEIGHT 48 // OLED display height, in pixels

// HH-12 absolute encoders connections params
// HSPI interface is used. ESP32 is master, HH-12 (for Az) and HH-12INC (for El) are slaves
#define hspi_clk_pin 14     // Common for both AZ and EL
#define az_hspi_cs_pin 15   // CS for AZ
#define el_hspi_cs_pin 5    // CS for El
#define hspi_miso_pin 12    // Common for both AZ and EL
