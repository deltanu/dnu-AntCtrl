// **** ---------------------- Features and Options, enable them below ------------------------------------------------
#define FEATURE_MOON_TRACKING
#define FEATURE_SUN_TRACKING

#define DEFAULT_GRID "JO99AH"		// Maidenhead grid Stockholm
#define DEFAULT_LATITUDE 59.3293	// Latitude Stockholm
#define DEFAULT_LONGITUDE 18.0686	// Longitude Stockholm
